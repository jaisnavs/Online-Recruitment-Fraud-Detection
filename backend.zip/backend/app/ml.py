import asyncio
from functools import lru_cache
from typing import Optional, Dict, List, Tuple

# Optional heavy deps. If unavailable, we degrade gracefully so the API can boot.
try:
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    np = None  # type: ignore

try:
    import torch  # type: ignore
except Exception:  # pragma: no cover
    torch = None  # type: ignore

try:
    from transformers import (
        BertTokenizer,
        BertModel,
        RobertaTokenizer,
        RobertaModel,
    )  # type: ignore
except Exception:  # pragma: no cover
    BertTokenizer = BertModel = RobertaTokenizer = RobertaModel = None  # type: ignore

import os

try:
    import pandas as pd  # type: ignore
except Exception:  # pragma: no cover
    pd = None  # type: ignore

try:
    from sklearn.linear_model import LogisticRegression  # type: ignore
except Exception:  # pragma: no cover
    LogisticRegression = None  # type: ignore


def clean_text(text: str) -> str:
    import re
    text = re.sub(r"http\S+|www\S+|https\S+| \S+@\S+", "", str(text))
    text = re.sub(r"\d+", "", text)
    text = re.sub(r"<.*?>", "", text)
    return text.lower().strip()


@lru_cache(maxsize=1)
def _load_bert():
    if BertTokenizer is None or BertModel is None or torch is None:
        return None, None, None
    tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
    model = BertModel.from_pretrained("bert-base-uncased")
    model.eval()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    return tokenizer, model, device


@lru_cache(maxsize=1)
def _load_roberta():
    if RobertaTokenizer is None or RobertaModel is None or torch is None:
        return None, None, None
    tokenizer = RobertaTokenizer.from_pretrained("roberta-base")
    model = RobertaModel.from_pretrained("roberta-base")
    model.eval()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    return tokenizer, model, device


def encode_text(text: str, encoder: str = "BERT"):
    """Return a 768-d embedding array if transformers/torch/numpy are available,
    otherwise return a lightweight fallback (list) of zeros to keep the API functional.
    """
    text = clean_text(text)
    if (BertTokenizer is None and RobertaTokenizer is None) or torch is None or np is None:
        # Fallback: fixed-size vector of zeros as plain list
        return [0.0] * 768
    if encoder == "RoBERTa":
        tokenizer, model, device = _load_roberta()
    else:
        tokenizer, model, device = _load_bert()
    if tokenizer is None or model is None or device is None:
        return [0.0] * 768
    if not text:
        return np.zeros(768, dtype=np.float32)
    with torch.no_grad():
        inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=512)
        inputs = {k: v.to(device) for k, v in inputs.items()}
        outputs = model(**inputs)
        emb = outputs.last_hidden_state.mean(dim=1).cpu().numpy().flatten()
        return emb.astype(np.float32)


class SimpleHeuristic:
    def predict_proba(self, emb, text: Optional[str] = None) -> float:
        # If numpy is available and emb is an array-like, use its norm; else use text length.
        if np is not None:
            try:
                norm = float(np.linalg.norm(emb) + 1e-8)  # type: ignore[arg-type]
                score = np.tanh((norm - 20.0) / 10.0)
                return max(0.0, min(1.0, (score + 1) / 2))
            except Exception:
                pass
        if text is None:
            return 0.5
        L = max(1, len(text))
        # Map length to a probability in [0.2, 0.8]
        score = 0.2 + min(0.6, (L / 500.0) * 0.6)
        return float(score)


heuristic_model = SimpleHeuristic()


def predict_fraud_probability(text: str) -> float:
    # If heavy deps are missing, fall back to text-length heuristic without failing.
    if np is None or BertTokenizer is None or torch is None:
        return heuristic_model.predict_proba(None, text)
    emb = encode_text(text, encoder="BERT")
    return heuristic_model.predict_proba(emb, text)


# ---------- Artifact discovery & cached classical models ----------

def _project_root() -> str:
    # Assuming backend runs with app-dir=backend; dataset/artifacts live at project root
    # Use two levels up from this file (backend/app/ml.py -> project root)
    here = os.path.abspath(os.path.dirname(__file__))
    return os.path.abspath(os.path.join(here, "..", ".."))


def list_artifacts() -> Tuple[bool, List[str], List[str]]:
    root = _project_root()
    dataset_found = os.path.exists(os.path.join(root, "fake_job_postings.csv")) or os.path.exists(
        os.path.join(root, "fake_job_postings_cleaned.csv")
    )
    files = set(os.listdir(root))
    encoders = []
    if "bert_encoded.pkl" in files:
        encoders.append("BERT")
    if "roberta_encoded.pkl" in files:
        encoders.append("RoBERTa")

    balanced = []
    for f in files:
        if f.endswith("_balanced.pkl") and (f.startswith("BERT_") or f.startswith("RoBERTa_")):
            # key format: Encoder_SMOTEVARIANT
            key = f.replace("_balanced.pkl", "")
            balanced.append(key)
    return dataset_found, encoders, balanced


_cached_lr: Dict[str, "LogisticRegression"] = {}


def _load_balanced_xy(key: str):
    root = _project_root()
    path = os.path.join(root, f"{key}_balanced.pkl")
    if not os.path.exists(path):
        return None
    if pd is None:
        return None
    df = pd.read_pickle(path)
    X = df.drop(columns=["fraudulent"]).values
    y = df["fraudulent"].values.astype(int)
    return X, y


def get_or_fit_lr_model(key: str):
    if key in _cached_lr:
        return _cached_lr[key]
    xy = _load_balanced_xy(key)
    if xy is None:
        return None
    X, y = xy
    # Simple, fast classifier; good for inference on existing SMOTE-balanced data
    if LogisticRegression is None:
        return None
    clf = LogisticRegression(max_iter=500, n_jobs=None)
    clf.fit(X, y)
    _cached_lr[key] = clf
    return clf


def predict_with_key(text: str, model_key: str) -> Optional[float]:
    """Predict using a classical model tied to a balanced dataset key (Encoder_SMOTE)."""
    clf = get_or_fit_lr_model(model_key)
    if clf is None:
        return None
    # We must encode text into the same feature space; since balanced data is in embedding space,
    # we encode with the corresponding encoder and feed to LR.
    encoder_name = model_key.split("_")[0]
    emb = encode_text(text, encoder=encoder_name)
    try:
        dim = emb.shape[0]  # type: ignore[attr-defined]
    except Exception:
        return None
    if dim != clf.coef_.shape[1]:
        # Feature mismatch
        return None
    prob1 = float(clf.predict_proba(emb.reshape(1, -1))[0, 1])
    return prob1


# ---------- Artifact generation (encode + SMOTE) ----------
try:
    from imblearn.over_sampling import SMOTE, BorderlineSMOTE, ADASYN, SVMSMOTE  # type: ignore
    from imblearn.combine import SMOTETomek, SMOTEENN  # type: ignore
    SMOTE_VARIANTS = {
        "SMOTE": SMOTE(random_state=42),
        "BorderlineSMOTE": BorderlineSMOTE(random_state=42),
        "ADASYN": ADASYN(random_state=42),
        "SVMSMOTE": SVMSMOTE(random_state=42),
        "SMOTETomek": SMOTETomek(random_state=42),
        "SMOTEENN": SMOTEENN(random_state=42),
    }
except Exception:  # pragma: no cover
    SMOTE_VARIANTS = {}


def _dataset_path() -> Optional[str]:
    root = _project_root()
    for name in ["fake_job_postings.csv", "fake_job_postings_cleaned.csv"]:
        p = os.path.join(root, name)
        if os.path.exists(p):
            return p
    return None


def _load_and_prepare_dataframe():
    path = _dataset_path()
    if not path:
        return None
    if pd is None:
        return None
    df = pd.read_csv(path)
    # Build text similar to your preprocessing
    for col in ["title", "description", "requirements", "benefits"]:
        if col not in df.columns:
            df[col] = ""
    df["text"] = (df["title"].fillna("") + " " + df["description"].fillna("") + " " +
                   df["requirements"].fillna("") + " " + df["benefits"].fillna("")).map(clean_text)
    if "fraudulent" not in df.columns:
        return None
    df["fraudulent"] = pd.to_numeric(df["fraudulent"], errors="coerce").fillna(0).astype(int)
    df = df.dropna(subset=["text", "fraudulent"]).drop_duplicates(subset=["text"]).reset_index(drop=True)
    return df


def generate_embeddings(encoder: str) -> Optional[str]:
    root = _project_root()
    df = _load_and_prepare_dataframe()
    if df is None:
        return None
    if np is None or pd is None:
        return None
    texts = df["text"].tolist()
    embs = []
    for t in texts:
        embs.append(encode_text(t, encoder=encoder))
    X = np.stack(embs)
    cols = [f"{encoder.lower()}_{i}" for i in range(X.shape[1])]
    out_df = pd.DataFrame(X, columns=cols)
    out_df["fraudulent"] = df["fraudulent"].values
    out_path = os.path.join(root, f"{encoder.lower()}_encoded.pkl")
    out_df.to_pickle(out_path)
    return out_path


def apply_smote(encoder: str, smote_variant: str) -> Optional[str]:
    root = _project_root()
    enc_path = os.path.join(root, f"{encoder.lower()}_encoded.pkl")
    if not os.path.exists(enc_path):
        # attempt to generate
        path = generate_embeddings(encoder)
        if path is None:
            return None
    if pd is None or not SMOTE_VARIANTS:
        return None
    emb_df = pd.read_pickle(enc_path)
    feature_cols = [c for c in emb_df.columns if c.startswith(encoder.lower())]
    X = emb_df[feature_cols].values
    y = emb_df["fraudulent"].values.astype(int)
    if smote_variant not in SMOTE_VARIANTS:
        smote_variant = "SMOTE"
    Xb, yb = SMOTE_VARIANTS[smote_variant].fit_resample(X, y)
    out_df = pd.DataFrame(Xb, columns=feature_cols)
    out_df["fraudulent"] = yb
    out_path = os.path.join(root, f"{encoder}_{smote_variant}_balanced.pkl")
    out_df.to_pickle(out_path)
    # clear cached LR if same key
    key = f"{encoder}_{smote_variant}"
    if key in _cached_lr:
        _cached_lr.pop(key, None)
    return out_path


