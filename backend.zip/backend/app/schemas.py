from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

class UserCreate(BaseModel):
    email: str
    password: str = Field(min_length=6)
    role: str  # 'seeker' or 'recruiter'

class UserOut(BaseModel):
    id: int
    email: str
    role: str
    created_at: datetime
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class Login(BaseModel):
    email: str
    password: str

class JobCreate(BaseModel):
    title: str
    description: str
    location: Optional[str] = None
    company: Optional[str] = None
    job_type: Optional[str] = None  # Full-time, Part-time, Contract, Internship
    remote: Optional[bool] = None
    experience_min: Optional[int] = None
    experience_max: Optional[int] = None
    salary_min: Optional[int] = None
    salary_max: Optional[int] = None

class JobOut(BaseModel):
    id: int
    title: str
    description: str
    is_open: bool
    recruiter_id: int
    created_at: datetime
    location: Optional[str] = None
    company: Optional[str] = None
    job_type: Optional[str] = None
    remote: Optional[bool] = None
    experience_min: Optional[int] = None
    experience_max: Optional[int] = None
    salary_min: Optional[int] = None
    salary_max: Optional[int] = None
    class Config:
        from_attributes = True

class PredictIn(BaseModel):
    text: str
    model_key: Optional[str] = None

class PredictOut(BaseModel):
    probability_fraud: float

class MLStatus(BaseModel):
    dataset_found: bool
    encoders_available: list[str]
    balanced_available: list[str]
    models_available: list[str]

class EncodeRequest(BaseModel):
    encoder: str  # 'BERT' or 'RoBERTa'
    force: bool = False

class SMOTERequest(BaseModel):
    encoder: str  # 'BERT' or 'RoBERTa'
    smote_variant: str  # e.g., 'SMOTE', 'ADASYN', etc.
    force: bool = False

class PrepareResult(BaseModel):
    path: str
    created_or_overwritten: bool


# Profile and Education
class UserProfileIn(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    location: Optional[str] = None
    headline: Optional[str] = None
    summary: Optional[str] = None
    linkedin_url: Optional[str] = None
    github_url: Optional[str] = None


class UserProfileOut(UserProfileIn):
    id: int
    user_id: int
    resume_path: Optional[str] = None
    updated_at: datetime
    class Config:
        from_attributes = True


class EducationIn(BaseModel):
    school: str
    degree: Optional[str] = None
    field: Optional[str] = None
    start_year: Optional[int] = None
    end_year: Optional[int] = None
    grade: Optional[str] = None


class EducationOut(EducationIn):
    id: int
    user_id: int
    class Config:
        from_attributes = True


# Applications
class ApplicationOut(BaseModel):
    id: int
    job_id: int
    seeker_id: int
    status: str
    note: Optional[str] = None
    created_at: datetime
    class Config:
        from_attributes = True


# Recruiter view models
class SeekerProfileBundle(BaseModel):
    profile: UserProfileOut
    educations: List[EducationOut]
    resume_available: bool

