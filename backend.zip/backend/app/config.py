import os
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "Job Testing Portal API"
    secret_key: str = os.getenv("JWT_SECRET", "supersecretkey")
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 60 * 24
    database_url: str = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./jobs.db")
    cors_origins: str = os.getenv("CORS_ORIGINS", "http://localhost:5173,http://localhost:3000")


settings = Settings()
