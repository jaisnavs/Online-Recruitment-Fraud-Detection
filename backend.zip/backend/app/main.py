import uvicorn
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_, or_
from typing import List, Optional

from .config import settings
from .database import engine, Base, get_db
from .models import User, Job, UserProfile, Education, Application
from .schemas import (
    UserCreate, UserOut, Login, Token, JobCreate, JobOut,
    PredictIn, PredictOut, MLStatus, EncodeRequest, SMOTERequest, PrepareResult,
    UserProfileIn, UserProfileOut, EducationIn, EducationOut, ApplicationOut,
    SeekerProfileBundle,
)
from .auth import get_password_hash, verify_password, create_access_token, get_current_user, require_role
from .ml import predict_fraud_probability, list_artifacts, predict_with_key, generate_embeddings, apply_smote

from fastapi.security import OAuth2PasswordRequestForm
import os
from fastapi.responses import FileResponse

app = FastAPI(title=settings.app_name)

origins = [o.strip() for o in settings.cors_origins.split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def on_startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        # Lightweight SQLite migrations for new Job columns
        try:
            res = await conn.exec_driver_sql("PRAGMA table_info(jobs)")
            cols = {row[1] for row in res}
            adds = []
            if "location" not in cols:
                adds.append("ALTER TABLE jobs ADD COLUMN location VARCHAR")
            if "company" not in cols:
                adds.append("ALTER TABLE jobs ADD COLUMN company VARCHAR")
            if "job_type" not in cols:
                adds.append("ALTER TABLE jobs ADD COLUMN job_type VARCHAR")
            if "remote" not in cols:
                adds.append("ALTER TABLE jobs ADD COLUMN remote BOOLEAN DEFAULT 0")
            if "experience_min" not in cols:
                adds.append("ALTER TABLE jobs ADD COLUMN experience_min INTEGER")
            if "experience_max" not in cols:
                adds.append("ALTER TABLE jobs ADD COLUMN experience_max INTEGER")
            if "salary_min" not in cols:
                adds.append("ALTER TABLE jobs ADD COLUMN salary_min INTEGER")
            if "salary_max" not in cols:
                adds.append("ALTER TABLE jobs ADD COLUMN salary_max INTEGER")
            for stmt in adds:
                await conn.exec_driver_sql(stmt)
        except Exception:
            # Best-effort; ignore if PRAGMA or ALTER not supported in other DBs
            pass
    # Seed default users
    async with AsyncSession(bind=engine) as db:
        # Seeker
        res1 = await db.execute(select(User).where(User.email == "seekergmail.com"))
        if res1.scalar_one_or_none() is None:
            db.add(User(email="seekergmail.com", password_hash=get_password_hash("seeker123"), role="seeker"))
        # Recruiter
        res2 = await db.execute(select(User).where(User.email == "recruitergmail.com"))
        if res2.scalar_one_or_none() is None:
            db.add(User(email="recruitergmail.com", password_hash=get_password_hash("recruiter123"), role="recruiter"))
        await db.commit()


# Auth routes
@app.post("/auth/register", response_model=UserOut)
async def register(payload: UserCreate, db: AsyncSession = Depends(get_db)):
    if payload.role not in {"seeker", "recruiter"}:
        raise HTTPException(status_code=400, detail="Invalid role")
    exists = await db.execute(select(User).where(User.email == payload.email))
    if exists.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Email already registered")
    user = User(email=payload.email, password_hash=get_password_hash(payload.password), role=payload.role)
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


@app.post("/auth/login", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends(), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(User).where(User.email == form_data.username))
    user = res.scalar_one_or_none()
    if not user or not verify_password(form_data.password, user.password_hash):
        raise HTTPException(status_code=400, detail="Incorrect email or password")
    token = create_access_token({"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer"}

@app.get("/auth/me", response_model=UserOut)
async def me(user: User = Depends(get_current_user)):
    return user


# Jobs public
@app.get("/jobs", response_model=List[JobOut])
async def list_open_jobs(
    location: Optional[str] = None,
    company: Optional[str] = None,
    job_type: Optional[str] = None,
    remote: Optional[bool] = None,
    exp_min: Optional[int] = None,
    exp_max: Optional[int] = None,
    salary_min: Optional[int] = None,
    salary_max: Optional[int] = None,
    q: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    stmt = select(Job).where(Job.is_open == True)
    if location:
        stmt = stmt.where(Job.location.ilike(f"%{location}%"))
    if company:
        stmt = stmt.where(Job.company.ilike(f"%{company}%"))
    if job_type:
        stmt = stmt.where(Job.job_type == job_type)
    if remote is not None:
        stmt = stmt.where(Job.remote == remote)
    if exp_min is not None:
        stmt = stmt.where(or_(Job.experience_min == None, Job.experience_min <= exp_min))
    if exp_max is not None:
        stmt = stmt.where(or_(Job.experience_max == None, Job.experience_max >= exp_max))
    if salary_min is not None:
        stmt = stmt.where(or_(Job.salary_min == None, Job.salary_min <= salary_min))
    if salary_max is not None:
        stmt = stmt.where(or_(Job.salary_max == None, Job.salary_max >= salary_max))
    if q:
        like = f"%{q}%"
        stmt = stmt.where(or_(Job.title.ilike(like), Job.description.ilike(like), Job.company.ilike(like)))
    stmt = stmt.order_by(Job.created_at.desc())
    res = await db.execute(stmt)
    return res.scalars().all()

@app.get("/jobs/{job_id}", response_model=JobOut)
async def get_job(job_id: int, db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Job).where(Job.id == job_id))
    job = res.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

# Profile endpoints
@app.get("/me/profile", response_model=UserProfileOut)
async def get_profile(user: User = Depends(require_role("seeker")), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(UserProfile).where(UserProfile.user_id == user.id))
    prof = res.scalar_one_or_none()
    if not prof:
        # Create an empty profile on first access
        prof = UserProfile(user_id=user.id)
        db.add(prof)
        await db.commit()
        await db.refresh(prof)
    return prof

@app.get("/me/profile/resume/download")
async def download_my_resume(user: User = Depends(require_role("seeker")), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(UserProfile).where(UserProfile.user_id == user.id))
    prof = res.scalar_one_or_none()
    if not prof or not prof.resume_path or not os.path.exists(prof.resume_path):
        raise HTTPException(status_code=404, detail="Resume not found")
    filename = os.path.basename(prof.resume_path)
    return FileResponse(prof.resume_path, media_type="application/octet-stream", filename=filename)

@app.put("/me/profile", response_model=UserProfileOut)
async def update_profile(payload: UserProfileIn, user: User = Depends(require_role("seeker")), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(UserProfile).where(UserProfile.user_id == user.id))
    prof = res.scalar_one_or_none()
    if not prof:
        prof = UserProfile(user_id=user.id)
        db.add(prof)
        await db.flush()
    for k, v in payload.dict().items():
        setattr(prof, k, v)
    await db.commit()
    await db.refresh(prof)
    return prof

@app.post("/me/profile/resume", response_model=UserProfileOut)
async def upload_resume(user: User = Depends(require_role("seeker")), file: UploadFile = File(...), db: AsyncSession = Depends(get_db)):
    if file.content_type not in {"application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"}:
        raise HTTPException(status_code=400, detail="Only PDF or Word documents are allowed")
    uploads_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "uploads"))
    os.makedirs(uploads_dir, exist_ok=True)
    filename = f"resume_user_{user.id}_{file.filename}"
    path = os.path.join(uploads_dir, filename)
    with open(path, "wb") as f:
        f.write(await file.read())
    res = await db.execute(select(UserProfile).where(UserProfile.user_id == user.id))
    prof = res.scalar_one_or_none()
    if not prof:
        prof = UserProfile(user_id=user.id)
        db.add(prof)
        await db.flush()
    prof.resume_path = path
    await db.commit()
    await db.refresh(prof)
    return prof

# Education endpoints
@app.get("/me/education", response_model=List[EducationOut])
async def list_education(user: User = Depends(require_role("seeker")), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Education).where(Education.user_id == user.id))
    return res.scalars().all()

@app.post("/me/education", response_model=EducationOut)
async def add_education(payload: EducationIn, user: User = Depends(require_role("seeker")), db: AsyncSession = Depends(get_db)):
    edu = Education(user_id=user.id, **payload.dict())
    db.add(edu)
    await db.commit()
    await db.refresh(edu)
    return edu

@app.delete("/me/education/{edu_id}")
async def delete_education(edu_id: int, user: User = Depends(require_role("seeker")), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Education).where(Education.id == edu_id, Education.user_id == user.id))
    edu = res.scalar_one_or_none()
    if not edu:
        raise HTTPException(status_code=404, detail="Education not found")
    await db.delete(edu)
    await db.commit()
    return {"ok": True}

# Applications
@app.post("/jobs/{job_id}/apply", response_model=ApplicationOut)
async def apply_job(job_id: int, user: User = Depends(require_role("seeker")), db: AsyncSession = Depends(get_db)):
    # Ensure job exists and open
    res = await db.execute(select(Job).where(Job.id == job_id))
    job = res.scalar_one_or_none()
    if not job or not job.is_open:
        raise HTTPException(status_code=404, detail="Job not found or closed")
    # Ensure profile completeness minimal: name and resume
    res = await db.execute(select(UserProfile).where(UserProfile.user_id == user.id))
    prof = res.scalar_one_or_none()
    if not prof or not prof.first_name or not prof.last_name or not prof.resume_path:
        raise HTTPException(status_code=400, detail="Complete your profile (name and resume) before applying")
    # Prevent duplicate application
    res = await db.execute(select(Application).where(Application.job_id == job_id, Application.seeker_id == user.id))
    existing = res.scalar_one_or_none()
    if existing:
        return existing
    app_obj = Application(job_id=job_id, seeker_id=user.id, status="applied")
    db.add(app_obj)
    await db.commit()
    await db.refresh(app_obj)
    return app_obj

# Recruiter: view applicant profile bundle and resume
@app.get("/recruiter/applications/{application_id}/seeker", response_model=SeekerProfileBundle)
async def recruiter_view_seeker(application_id: int, user: User = Depends(require_role("recruiter")), db: AsyncSession = Depends(get_db)):
    # Load application
    res = await db.execute(select(Application).where(Application.id == application_id))
    app_obj = res.scalar_one_or_none()
    if not app_obj:
        raise HTTPException(status_code=404, detail="Application not found")
    # Ensure recruiter owns the job
    res = await db.execute(select(Job).where(Job.id == app_obj.job_id, Job.recruiter_id == user.id))
    job = res.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=403, detail="Forbidden")
    # Fetch profile and education
    res = await db.execute(select(UserProfile).where(UserProfile.user_id == app_obj.seeker_id))
    profile = res.scalar_one_or_none()
    res = await db.execute(select(Education).where(Education.user_id == app_obj.seeker_id).order_by(Education.start_year.desc().nulls_last()))
    edus = res.scalars().all()
    if not profile:
        # Create an empty shell for response if seeker never opened profile
        profile = UserProfile(user_id=app_obj.seeker_id)
    bundle = SeekerProfileBundle(
        profile=profile,
        educations=edus,
        resume_available=bool(profile.resume_path and os.path.exists(profile.resume_path))
    )
    return bundle

@app.get("/recruiter/applications/{application_id}/resume")
async def recruiter_download_resume(application_id: int, user: User = Depends(require_role("recruiter")), db: AsyncSession = Depends(get_db)):
    # Load application
    res = await db.execute(select(Application).where(Application.id == application_id))
    app_obj = res.scalar_one_or_none()
    if not app_obj:
        raise HTTPException(status_code=404, detail="Application not found")
    # Ensure recruiter owns the job
    res = await db.execute(select(Job).where(Job.id == app_obj.job_id, Job.recruiter_id == user.id))
    job = res.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=403, detail="Forbidden")
    # Find resume
    res = await db.execute(select(UserProfile).where(UserProfile.user_id == app_obj.seeker_id))
    prof = res.scalar_one_or_none()
    if not prof or not prof.resume_path or not os.path.exists(prof.resume_path):
        raise HTTPException(status_code=404, detail="Resume not found")
    filename = os.path.basename(prof.resume_path)
    return FileResponse(prof.resume_path, media_type="application/octet-stream", filename=filename)

@app.get("/applications", response_model=List[ApplicationOut])
async def my_applications(status: Optional[str] = None, user: User = Depends(require_role("seeker")), db: AsyncSession = Depends(get_db)):
    stmt = select(Application).where(Application.seeker_id == user.id)
    if status:
        stmt = stmt.where(Application.status == status)
    stmt = stmt.order_by(Application.created_at.desc())
    res = await db.execute(stmt)
    return res.scalars().all()

# Recruiter: view/filter applications and accept/reject
@app.get("/recruiter/jobs/{job_id}/applications", response_model=List[ApplicationOut])
async def list_job_applications(
    job_id: int,
    status: Optional[str] = None,
    exp_min: Optional[int] = None,
    exp_max: Optional[int] = None,
    q: Optional[str] = None,
    user: User = Depends(require_role("recruiter")),
    db: AsyncSession = Depends(get_db),
):
    # Ensure ownership
    res = await db.execute(select(Job).where(Job.id == job_id, Job.recruiter_id == user.id))
    job = res.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found or not owned by user")
    from .models import User as MUser, UserProfile as MProfile
    stmt = select(Application).where(Application.job_id == job_id)
    # Join to enable filters
    stmt = stmt.join(MUser, Application.seeker_id == MUser.id)
    stmt = stmt.join(MProfile, MProfile.user_id == MUser.id, isouter=True)
    if status:
        stmt = stmt.where(Application.status == status)
    if exp_min is not None:
        stmt = stmt.where(or_(MProfile.experience_years == None, MProfile.experience_years >= exp_min))
    if exp_max is not None:
        stmt = stmt.where(or_(MProfile.experience_years == None, MProfile.experience_years <= exp_max))
    if q:
        like = f"%{q}%"
        stmt = stmt.where(or_(MProfile.headline.ilike(like), MProfile.summary.ilike(like), MProfile.location.ilike(like)))
    stmt = stmt.order_by(Application.created_at.desc())
    res = await db.execute(stmt)
    return res.scalars().all()

@app.patch("/recruiter/applications/{application_id}", response_model=ApplicationOut)
async def decide_application(application_id: int, action: str = Form(...), note: Optional[str] = Form(None), user: User = Depends(require_role("recruiter")), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Application).where(Application.id == application_id))
    app_obj = res.scalar_one_or_none()
    if not app_obj:
        raise HTTPException(status_code=404, detail="Application not found")
    # Ensure ownership
    res = await db.execute(select(Job).where(Job.id == app_obj.job_id, Job.recruiter_id == user.id))
    job = res.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=403, detail="Forbidden")
    if action not in {"accept", "reject"}:
        raise HTTPException(status_code=400, detail="Invalid action")
    app_obj.status = "accepted" if action == "accept" else "rejected"
    app_obj.note = note
    await db.commit()
    await db.refresh(app_obj)
    return app_obj


# Recruiter routes
@app.get("/recruiter/jobs", response_model=List[JobOut])
async def my_jobs(user: User = Depends(require_role("recruiter")), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Job).where(Job.recruiter_id == user.id).order_by(Job.created_at.desc()))
    return res.scalars().all()

@app.post("/recruiter/jobs", response_model=JobOut)
async def create_job(payload: JobCreate, user: User = Depends(require_role("recruiter")), db: AsyncSession = Depends(get_db)):
    job = Job(
        title=payload.title,
        description=payload.description,
        recruiter_id=user.id,
        is_open=True,
        location=payload.location,
        company=payload.company,
        job_type=payload.job_type,
        remote=payload.remote if payload.remote is not None else False,
        experience_min=payload.experience_min,
        experience_max=payload.experience_max,
        salary_min=payload.salary_min,
        salary_max=payload.salary_max,
    )
    db.add(job)
    await db.commit()
    await db.refresh(job)
    return job

@app.patch("/recruiter/jobs/{job_id}/toggle", response_model=JobOut)
async def toggle_job(job_id: int, user: User = Depends(require_role("recruiter")), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Job).where(Job.id == job_id, Job.recruiter_id == user.id))
    job = res.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found or not owned by user")
    job.is_open = not job.is_open
    await db.commit()
    await db.refresh(job)
    return job


# Prediction route
@app.post("/predict", response_model=PredictOut)
async def predict(payload: PredictIn):
    # Try model_key-based prediction on existing balanced data (Encoder_SMOTE)
    if payload.model_key:
        prob = predict_with_key(payload.text, payload.model_key)
        if prob is not None:
            return {"probability_fraud": float(prob)}
    # Fallback to encoder heuristic
    prob = predict_fraud_probability(payload.text)
    return {"probability_fraud": float(prob)}


@app.get("/ml/status", response_model=MLStatus)
async def ml_status():
    dataset_found, encoders, balanced = list_artifacts()
    # For now, models_available equals balanced keys (LR is fit on demand per key)
    return {
        "dataset_found": dataset_found,
        "encoders_available": encoders,
        "balanced_available": balanced,
        "models_available": balanced,
    }


@app.post("/ml/encode", response_model=PrepareResult)
async def ml_encode(req: EncodeRequest):
    import os
    root_file = f"{req.encoder.lower()}_encoded.pkl"
    root_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", root_file))
    exists = os.path.exists(root_path)
    if exists and not req.force:
        return {"path": root_path, "created_or_overwritten": False}
    path = generate_embeddings(req.encoder)
    if path is None:
        raise HTTPException(status_code=400, detail="Dataset not found or invalid for encoding")
    return {"path": path, "created_or_overwritten": True}


@app.post("/ml/smote", response_model=PrepareResult)
async def ml_smote(req: SMOTERequest):
    import os
    key = f"{req.encoder}_{req.smote_variant}"
    root_file = f"{key}_balanced.pkl"
    root_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", root_file))
    exists = os.path.exists(root_path)
    if exists and not req.force:
        return {"path": root_path, "created_or_overwritten": False}
    path = apply_smote(req.encoder, req.smote_variant)
    if path is None:
        raise HTTPException(status_code=400, detail="Unable to create balanced dataset (missing dataset/encoder)")
    return {"path": path, "created_or_overwritten": True}


if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
