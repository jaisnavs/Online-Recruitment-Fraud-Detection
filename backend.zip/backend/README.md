# Backend - Job Testing Portal API

Run locally:

1. Create venv and install deps
   - Windows PowerShell
     ```powershell
     python -m venv .venv
     .venv\\Scripts\\Activate.ps1
     pip install -r backend/requirements.txt
     ```
2. Start API
   ```powershell
   uvicorn app.main:app --reload --port 8000
   ```

Environment:
- JWT_SECRET, DATABASE_URL, CORS_ORIGINS (comma-separated)

Notes:
- /auth/register (email, password, role)
- /auth/login (OAuth2 form: username=email, password)
- /jobs public list of open jobs
- /recruiter/jobs (Bearer) manage jobs, toggle open/closed
- /predict accepts { text } and returns probability_fraud using BERT embedding + heuristic by default. Replace with your trained head if available.
