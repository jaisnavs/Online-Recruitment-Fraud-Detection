import React, { useEffect, useMemo, useState } from 'react'
import api from '../api/client'

const SMOTE_VARIANTS = [
  'SMOTE', 'BorderlineSMOTE', 'ADASYN', 'SVMSMOTE', 'SMOTETomek', 'SMOTEENN'
]

export default function Predict() {
  const [text, setText] = useState('')
  const [prob, setProb] = useState(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const [status, setStatus] = useState({
    dataset_found: false,
    encoders_available: [],
    balanced_available: [],
    models_available: [],
  })

  const [encoder, setEncoder] = useState('BERT')
  const [smote, setSmote] = useState('SMOTE')
  const [force, setForce] = useState(false)
  const [modelKey, setModelKey] = useState('')

  const desiredKey = useMemo(() => `${encoder}_${smote}`, [encoder, smote])

  const loadStatus = async () => {
    const res = await api.get('/ml/status')
    setStatus(res.data)
  }

  useEffect(() => { loadStatus() }, [])

  useEffect(() => {
    // preselect model if available
    if (status.models_available?.includes(desiredKey)) {
      setModelKey(desiredKey)
    } else if (status.models_available?.length) {
      setModelKey(status.models_available[0])
    } else {
      setModelKey('')
    }
  }, [status, desiredKey])

  const ensureEncoded = async () => {
    setBusy(true)
    setError('')
    try {
      await api.post('/ml/encode', { encoder, force })
      await loadStatus()
    } catch (e) {
      setError(e.response?.data?.detail || 'Encode failed')
    } finally { setBusy(false) }
  }

  const ensureBalanced = async () => {
    setBusy(true)
    setError('')
    try {
      await api.post('/ml/smote', { encoder, smote_variant: smote, force })
      await loadStatus()
    } catch (e) {
      setError(e.response?.data?.detail || 'SMOTE failed')
    } finally { setBusy(false) }
  }

  const predict = async (e) => {
    e.preventDefault()
    setError('')
    setProb(null)
    setBusy(true)
    try {
      const body = modelKey ? { text, model_key: modelKey } : { text }
      const res = await api.post('/predict', body)
      setProb(res.data.probability_fraud)
    } catch (e) {
      setError(e.response?.data?.detail || 'Prediction failed')
    } finally { setBusy(false) }
  }

  return (
    <div>
      <h2>Fraud Probability Check</h2>

      <div className="card">
        <h3>Artifacts</h3>
        <div style={{ display: 'grid', gap: 12 }}>
          <div>
            <label>Encoder</label>
            <select value={encoder} onChange={(e) => setEncoder(e.target.value)}>
              <option value="BERT">BERT</option>
              <option value="RoBERTa">RoBERTa</option>
            </select>
          </div>
          <div>
            <label>SMOTE Variant</label>
            <select value={smote} onChange={(e) => setSmote(e.target.value)}>
              {SMOTE_VARIANTS.map(v => <option key={v} value={v}>{v}</option>)}
            </select>
          </div>
          <div>
            <label>
              <input type="checkbox" checked={force} onChange={(e) => setForce(e.target.checked)} />
              {' '}Regenerate (overwrite if exists)
            </label>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button className="btn btn-secondary" onClick={ensureEncoded} disabled={busy}>Encode {encoder}</button>
            <button className="btn btn-secondary" onClick={ensureBalanced} disabled={busy}>SMOTE {desiredKey}</button>
          </div>
          <div>
            <label>Available Models (from balanced files)</label>
            <select value={modelKey} onChange={(e) => setModelKey(e.target.value)}>
              <option value="">Heuristic (no balanced model)</option>
              {status.models_available?.map(k => (
                <option key={k} value={k}>{k}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="card">
        <form onSubmit={predict}>
          <label>Paste job post text</label>
          <textarea value={text} onChange={(e) => setText(e.target.value)} rows={10} placeholder="Enter job description..." required />
          {error && <div className="error">{error}</div>}
          <button className="btn" disabled={busy}>{busy ? 'Working...' : 'Predict'}</button>
        </form>
      </div>

      {prob !== null && (
        <div className="result">
          <h3>Result</h3>
          <div className="meter">
            <div className="fill" style={{ width: `${(prob * 100).toFixed(1)}%` }} />
          </div>
          <p><strong>Probability of Fraud:</strong> {(prob * 100).toFixed(2)}%</p>
          <p><em>{prob > 0.6 ? 'High risk 🚨' : prob > 0.35 ? 'Medium risk ⚠️' : 'Low risk ✅'}</em></p>
        </div>
      )}
    </div>
  )
}
