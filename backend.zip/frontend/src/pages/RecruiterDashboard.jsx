import React, { useEffect, useState } from 'react'
import api from '../api/client'

export default function RecruiterDashboard() {
  const [jobs, setJobs] = useState([])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [company, setCompany] = useState('')
  const [location, setLocation] = useState('')
  const [jobType, setJobType] = useState('')
  const [remote, setRemote] = useState('')
  const [expMin, setExpMin] = useState('')
  const [expMax, setExpMax] = useState('')
  const [salaryMin, setSalaryMin] = useState('')
  const [salaryMax, setSalaryMax] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [selectedJob, setSelectedJob] = useState(null)
  const [appStatus, setAppStatus] = useState('')
  const [applications, setApplications] = useState([])
  const [appsLoading, setAppsLoading] = useState(false)
  const [appsError, setAppsError] = useState('')
  const [viewerAppId, setViewerAppId] = useState(null)
  const [viewerLoading, setViewerLoading] = useState(false)
  const [viewerError, setViewerError] = useState('')
  const [bundle, setBundle] = useState(null)

  const load = async () => {
    setError('')
    try {
      const res = await api.get('/recruiter/jobs')
      setJobs(res.data)
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to load jobs')
    }
  }

  useEffect(() => { load() }, [])

  const createJob = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const payload = {
        title,
        description,
        company: company || null,
        location: location || null,
        job_type: jobType || null,
        remote: remote === '' ? null : remote === 'true',
        experience_min: expMin === '' ? null : Number(expMin),
        experience_max: expMax === '' ? null : Number(expMax),
        salary_min: salaryMin === '' ? null : Number(salaryMin),
        salary_max: salaryMax === '' ? null : Number(salaryMax),
      }
      await api.post('/recruiter/jobs', payload)
      setTitle('')
      setDescription('')
      setCompany('')
      setLocation('')
      setJobType('')
      setRemote('')
      setExpMin('')
      setExpMax('')
      setSalaryMin('')
      setSalaryMax('')
      await load()
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to create job')
    } finally {
      setLoading(false)
    }
  }

  const toggle = async (id) => {
    try {
      await api.patch(`/recruiter/jobs/${id}/toggle`)
      await load()
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to toggle job')
    }
  }

  const loadApplications = async () => {
    if (!selectedJob) return
    setAppsLoading(true)
    setAppsError('')
    try {
      const res = await api.get(`/recruiter/jobs/${selectedJob}/applications`, { params: { status: appStatus || undefined } })
      setApplications(res.data)
    } catch (e) {
      setAppsError(e.response?.data?.detail || 'Failed to load applications')
    } finally {
      setAppsLoading(false)
    }
  }

  useEffect(() => { loadApplications() }, [selectedJob, appStatus])

  const decide = async (id, action) => {
    const note = window.prompt(`${action === 'accept' ? 'Accept' : 'Reject'} application #${id}. Add a note (optional):`)
    try {
      const form = new FormData()
      form.append('action', action)
      if (note) form.append('note', note)
      await api.patch(`/recruiter/applications/${id}`, form)
      await loadApplications()
    } catch (e) {
      alert(e.response?.data?.detail || 'Failed to update application')
    }
  }

  const viewSeeker = async (applicationId) => {
    setViewerAppId(applicationId)
    setViewerLoading(true)
    setViewerError('')
    setBundle(null)
    try {
      const res = await api.get(`/recruiter/applications/${applicationId}/seeker`)
      setBundle(res.data)
    } catch (e) {
      setViewerError(e.response?.data?.detail || 'Failed to load applicant profile')
    } finally {
      setViewerLoading(false)
    }
  }

  return (
    <div>
      <h2>Recruiter Dashboard</h2>

      <div className="card">
        <h3>Create Job</h3>
        <form onSubmit={createJob}>
          <label>Title</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} required />
          <label>Description</label>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} required rows={6} />
          <div className="grid-3">
            <div>
              <label>Company</label>
              <input value={company} onChange={(e) => setCompany(e.target.value)} />
            </div>
            <div>
              <label>Location</label>
              <input value={location} onChange={(e) => setLocation(e.target.value)} />
            </div>
            <div>
              <label>Job Type</label>
              <select value={jobType} onChange={(e) => setJobType(e.target.value)}>
                <option value="">Any</option>
                <option value="Full-time">Full-time</option>
                <option value="Part-time">Part-time</option>
                <option value="Contract">Contract</option>
                <option value="Internship">Internship</option>
              </select>
            </div>
            <div>
              <label>Remote</label>
              <select value={remote} onChange={(e) => setRemote(e.target.value)}>
                <option value="">On-site/Remote</option>
                <option value="true">Remote</option>
                <option value="false">On-site</option>
              </select>
            </div>
            <div>
              <label>Experience Min</label>
              <input type="number" value={expMin} onChange={(e) => setExpMin(e.target.value)} />
            </div>
            <div>
              <label>Experience Max</label>
              <input type="number" value={expMax} onChange={(e) => setExpMax(e.target.value)} />
            </div>
            <div>
              <label>Salary Min</label>
              <input type="number" value={salaryMin} onChange={(e) => setSalaryMin(e.target.value)} />
            </div>
            <div>
              <label>Salary Max</label>
              <input type="number" value={salaryMax} onChange={(e) => setSalaryMax(e.target.value)} />
            </div>
          </div>
          {error && <div className="error">{error}</div>}
          <button className="btn" disabled={loading}>{loading ? 'Creating...' : 'Create'}</button>
        </form>
      </div>

      <h3>Your Jobs</h3>
      <div className="list">
        {jobs.map((j) => (
          <div key={j.id} className="list-item">
            <div className="title">{j.title}</div>
            <div className="meta">ID #{j.id} · {j.company || 'Company'} · {j.location || 'Location'} · {j.job_type || 'Type'} · {j.is_open ? 'Open' : 'Closed'}</div>
            <p className="clamp">{j.description}</p>
            <button className="btn btn-secondary" onClick={() => toggle(j.id)}>
              Toggle {j.is_open ? 'Close' : 'Open'}
            </button>
            <button className="btn" style={{ marginLeft: 8 }} onClick={() => setSelectedJob(j.id)}>View Applications</button>
          </div>
        ))}
        {jobs.length === 0 && <div>No jobs yet. Create one above.</div>}
      </div>

      {selectedJob && (
        <div className="card" style={{ marginTop: 16 }}>
          <h3>Applications for Job #{selectedJob}</h3>
          <label>Status Filter</label>
          <select value={appStatus} onChange={(e) => setAppStatus(e.target.value)}>
            <option value="">All</option>
            <option value="applied">Applied</option>
            <option value="accepted">Accepted</option>
            <option value="rejected">Rejected</option>
          </select>
          {appsLoading && <div>Loading...</div>}
          {appsError && <div className="error">{appsError}</div>}
          <div className="list">
            {applications.map((a) => (
              <div key={a.id} className="list-item">
                <div className="title">Application #{a.id}</div>
                <div className="meta">Seeker #{a.seeker_id} · {new Date(a.created_at).toLocaleString()}</div>
                <div className={`badge ${a.status}`}>{a.status}</div>
                {a.note && <div className="meta">Note: {a.note}</div>}
                <div style={{ marginTop: 8 }}>
                  <button className="btn btn-secondary" onClick={() => viewSeeker(a.id)}>View Applicant</button>
                  <a className="btn" style={{ marginLeft: 8 }} href={`${api.defaults.baseURL}/recruiter/applications/${a.id}/resume`} target="_blank" rel="noreferrer">Download Resume</a>
                </div>
                {a.status === 'applied' && (
                  <div>
                    <button className="btn" onClick={() => decide(a.id, 'accept')}>Accept</button>
                    <button className="btn btn-secondary" style={{ marginLeft: 8 }} onClick={() => decide(a.id, 'reject')}>Reject</button>
                  </div>
                )}

                {viewerAppId === a.id && (
                  <div className="card" style={{ marginTop: 12 }}>
                    <h4>Applicant Profile</h4>
                    {viewerLoading && <div>Loading...</div>}
                    {viewerError && <div className="error">{viewerError}</div>}
                    {bundle && (
                      <div>
                        <div className="grid-2">
                          <div>
                            <div className="title">{bundle.profile.first_name || ''} {bundle.profile.last_name || ''}</div>
                            <div className="meta">{bundle.profile.headline || ''}</div>
                            <div className="meta">{bundle.profile.location || ''} {bundle.profile.phone ? `· ${bundle.profile.phone}` : ''}</div>
                          </div>
                          <div>
                            <div className="meta">Experience: {bundle.profile.experience_years ?? 'N/A'} years</div>
                            <div className="meta">LinkedIn: {bundle.profile.linkedin_url ? <a href={bundle.profile.linkedin_url} target="_blank" rel="noreferrer">Profile</a> : '—'}</div>
                            <div className="meta">GitHub: {bundle.profile.github_url ? <a href={bundle.profile.github_url} target="_blank" rel="noreferrer">Profile</a> : '—'}</div>
                          </div>
                        </div>
                        {bundle.profile.summary && (
                          <div>
                            <label>Summary</label>
                            <p style={{ whiteSpace: 'pre-wrap' }}>{bundle.profile.summary}</p>
                          </div>
                        )}
                        <div>
                          <h5>Education</h5>
                          <div className="list">
                            {bundle.educations.map(ed => (
                              <div key={ed.id} className="list-item">
                                <div className="title">{ed.school} {ed.degree ? `· ${ed.degree}` : ''}</div>
                                <div className="meta">{ed.field || ''} {ed.start_year || ''} - {ed.end_year || ''}</div>
                              </div>
                            ))}
                            {bundle.educations.length === 0 && <div>No education entries.</div>}
                          </div>
                        </div>
                        <div style={{ marginTop: 8 }}>
                          {bundle.resume_available ? (
                            <a className="btn" href={`${api.defaults.baseURL}/recruiter/applications/${a.id}/resume`} target="_blank" rel="noreferrer">View/Download Resume</a>
                          ) : (
                            <div className="meta">No resume uploaded</div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
            {!appsLoading && applications.length === 0 && <div>No applications.</div>}
          </div>
        </div>
      )}
    </div>
  )
}

