import React, { useEffect, useState } from 'react'
import api from '../api/client'

export default function Profile() {
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [resumeFile, setResumeFile] = useState(null)

  const [edus, setEdus] = useState([])
  const [eduForm, setEduForm] = useState({ school: '', degree: '', field: '', start_year: '', end_year: '', grade: '' })

  const load = async () => {
    setLoading(true)
    setError('')
    try {
      const [p, e] = await Promise.all([
        api.get('/me/profile'),
        api.get('/me/education'),
      ])
      setProfile(p.data)
      setEdus(e.data)
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to load profile')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const onChange = (k, v) => setProfile({ ...profile, [k]: v })

  const save = async (e) => {
    e.preventDefault()
    setSaving(true)
    setError('')
    try {
      const payload = { ...profile }
      delete payload.id
      delete payload.user_id
      delete payload.resume_path
      delete payload.updated_at
      await api.put('/me/profile', payload)
      if (resumeFile) {
        const form = new FormData()
        form.append('file', resumeFile)
        await api.post('/me/profile/resume', form, { headers: { 'Content-Type': 'multipart/form-data' } })
        setResumeFile(null)
      }
      await load()
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to save')
    } finally {
      setSaving(false)
    }
  }

  const onSelectResume = (e) => {
    const file = e.target.files?.[0]
    setResumeFile(file || null)
  }

  const addEdu = async (e) => {
    e.preventDefault()
    setError('')
    try {
      const payload = { ...eduForm }
      ;['start_year','end_year'].forEach(k => { if (payload[k] === '') payload[k] = null; else payload[k] = Number(payload[k]) })
      await api.post('/me/education', payload)
      setEduForm({ school: '', degree: '', field: '', start_year: '', end_year: '', grade: '' })
      await load()
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to add education')
    }
  }

  const removeEdu = async (id) => {
    try {
      await api.delete(`/me/education/${id}`)
      await load()
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to remove education')
    }
  }

  if (loading) return <div>Loading...</div>
  if (error) return <div className="error">{error}</div>
  if (!profile) return <div>No profile</div>

  return (
    <div>
      <h2>My Profile</h2>
      <form onSubmit={save}>
        <div className="card">
          <h3>Basic Info</h3>
          <div className="grid-2">
            <div>
              <label>First Name</label>
              <input value={profile.first_name || ''} onChange={(e) => onChange('first_name', e.target.value)} />
            </div>
            <div>
              <label>Last Name</label>
              <input value={profile.last_name || ''} onChange={(e) => onChange('last_name', e.target.value)} />
            </div>
            <div>
              <label>Phone</label>
              <input value={profile.phone || ''} onChange={(e) => onChange('phone', e.target.value)} />
            </div>
            <div>
              <label>Location</label>
              <input value={profile.location || ''} onChange={(e) => onChange('location', e.target.value)} />
            </div>
          </div>
        </div>

        <div className="card">
          <h3>Professional</h3>
          <div className="grid-2">
            <div>
              <label>Headline</label>
              <input value={profile.headline || ''} onChange={(e) => onChange('headline', e.target.value)} />
            </div>
            <div>
              <label>Experience (years)</label>
              <input type="number" value={profile.experience_years || ''} onChange={(e) => onChange('experience_years', e.target.value === '' ? null : Number(e.target.value))} />
            </div>
          </div>
          <label>Summary</label>
          <textarea rows={4} value={profile.summary || ''} onChange={(e) => onChange('summary', e.target.value)} />
          <div className="grid-2">
            <div>
              <label>LinkedIn URL</label>
              <input value={profile.linkedin_url || ''} onChange={(e) => onChange('linkedin_url', e.target.value)} />
            </div>
            <div>
              <label>GitHub URL</label>
              <input value={profile.github_url || ''} onChange={(e) => onChange('github_url', e.target.value)} />
            </div>
          </div>
        </div>

        <div className="card">
          <h3>Resume</h3>
          <input type="file" accept=".pdf,.doc,.docx" onChange={onSelectResume} />
          {resumeFile && <div className="meta">Selected: {resumeFile.name}</div>}
          {profile.resume_path ? (
            <div style={{ marginTop: 8 }}>
              <div className="meta">Uploaded: {profile.resume_path.split('\\').pop()}</div>
              <a className="btn" href={`${api.defaults.baseURL}/me/profile/resume/download`} target="_blank" rel="noreferrer">View/Download Resume</a>
              {String(profile.resume_path).toLowerCase().endsWith('.pdf') && (
                <div style={{ marginTop: 8 }}>
                  <iframe title="resume" src={`${api.defaults.baseURL}/me/profile/resume/download`} style={{ width: '100%', height: 480, border: '1px solid #e5e7eb' }} />
                </div>
              )}
            </div>
          ) : (
            <div className="meta">No resume uploaded</div>
          )}
        </div>

        <div className="card">
          <h3>Education</h3>
          <form onSubmit={addEdu} className="grid-3">
            <input placeholder="School" value={eduForm.school} onChange={(e) => setEduForm({ ...eduForm, school: e.target.value })} required />
            <input placeholder="Degree" value={eduForm.degree} onChange={(e) => setEduForm({ ...eduForm, degree: e.target.value })} />
            <input placeholder="Field" value={eduForm.field} onChange={(e) => setEduForm({ ...eduForm, field: e.target.value })} />
            <input placeholder="Start Year" type="number" value={eduForm.start_year} onChange={(e) => setEduForm({ ...eduForm, start_year: e.target.value })} />
            <input placeholder="End Year" type="number" value={eduForm.end_year} onChange={(e) => setEduForm({ ...eduForm, end_year: e.target.value })} />
            <input placeholder="Grade" value={eduForm.grade} onChange={(e) => setEduForm({ ...eduForm, grade: e.target.value })} />
            <button className="btn">Add</button>
          </form>
          <div className="list">
            {edus.map((ed) => (
              <div key={ed.id} className="list-item">
                <div className="title">{ed.school} {ed.degree ? `· ${ed.degree}` : ''}</div>
                <div className="meta">{ed.field || ''} {ed.start_year || ''} - {ed.end_year || ''}</div>
                <button className="btn btn-secondary" onClick={() => removeEdu(ed.id)}>Remove</button>
              </div>
            ))}
            {edus.length === 0 && <div>No education entries yet.</div>}
          </div>
        </div>

        {error && <div className="error" style={{ marginBottom: 8 }}>{error}</div>}
        <div className="card" style={{ position: 'sticky', bottom: 0, zIndex: 10 }}>
          <button className="btn" disabled={saving}>{saving ? 'Saving...' : 'Save All'}</button>
        </div>
      </form>

    </div>
  )
}
