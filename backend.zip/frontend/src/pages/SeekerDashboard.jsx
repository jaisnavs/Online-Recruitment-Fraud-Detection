import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../api/client'
import { useAuth } from '../state/AuthContext'

export default function SeekerDashboard() {
  const [jobs, setJobs] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [filters, setFilters] = useState({ q: '', location: '', company: '', job_type: '', remote: '', exp_min: '', exp_max: '', salary_min: '', salary_max: '' })
  const { user } = useAuth()
  const [incompleteProfile, setIncompleteProfile] = useState(false)

  const load = async () => {
    setLoading(true)
    setError('')
    try {
      const params = {}
      Object.entries(filters).forEach(([k, v]) => {
        if (v !== '' && v !== null && v !== undefined) params[k] = v
      })
      if (filters.remote === 'true') params.remote = true
      if (filters.remote === 'false') params.remote = false
      const res = await api.get('/jobs', { params })
      setJobs(res.data)
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to load jobs')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])
  useEffect(() => {
    const checkProfile = async () => {
      if (user?.role !== 'seeker') return
      try {
        const res = await api.get('/me/profile')
        const p = res.data
        setIncompleteProfile(!(p.first_name && p.last_name && p.resume_path))
      } catch {}
    }
    checkProfile()
  }, [user])

  return (
    <div>
      <h2>Available Jobs</h2>
      {user?.role === 'seeker' && incompleteProfile && (
        <div className="card warning">
          <div><strong>Complete your profile</strong> with your personal, educational info and upload a resume to apply to jobs.</div>
          <Link to="/profile" className="btn" style={{ marginTop: 8 }}>Go to Profile</Link>
        </div>
      )}
      <div className="card">
        <div className="grid-4">
          <input placeholder="Search title, description, company" value={filters.q} onChange={(e) => setFilters({ ...filters, q: e.target.value })} />
          <input placeholder="Location" value={filters.location} onChange={(e) => setFilters({ ...filters, location: e.target.value })} />
          <input placeholder="Company" value={filters.company} onChange={(e) => setFilters({ ...filters, company: e.target.value })} />
          <select value={filters.job_type} onChange={(e) => setFilters({ ...filters, job_type: e.target.value })}>
            <option value="">Any Type</option>
            <option value="Full-time">Full-time</option>
            <option value="Part-time">Part-time</option>
            <option value="Contract">Contract</option>
            <option value="Internship">Internship</option>
          </select>
          <select value={filters.remote} onChange={(e) => setFilters({ ...filters, remote: e.target.value })}>
            <option value="">On-site/Remote</option>
            <option value="true">Remote</option>
            <option value="false">On-site</option>
          </select>
          <input type="number" placeholder="Min Exp" value={filters.exp_min} onChange={(e) => setFilters({ ...filters, exp_min: e.target.value })} />
          <input type="number" placeholder="Max Exp" value={filters.exp_max} onChange={(e) => setFilters({ ...filters, exp_max: e.target.value })} />
          <input type="number" placeholder="Min Salary" value={filters.salary_min} onChange={(e) => setFilters({ ...filters, salary_min: e.target.value })} />
          <input type="number" placeholder="Max Salary" value={filters.salary_max} onChange={(e) => setFilters({ ...filters, salary_max: e.target.value })} />
        </div>
        <div style={{ marginTop: 8 }}>
          <button className="btn" onClick={load}>Apply Filters</button>
          <button className="btn btn-secondary" style={{ marginLeft: 8 }} onClick={() => { setFilters({ q: '', location: '', company: '', job_type: '', remote: '', exp_min: '', exp_max: '', salary_min: '', salary_max: '' }); load() }}>Reset</button>
        </div>
      </div>
      {loading && <div>Loading...</div>}
      {error && <div className="error">{error}</div>}
      <div className="list">
        {jobs.map((j) => (
          <Link key={j.id} to={`/jobs/${j.id}`} className="list-item">
            <div className="title">{j.title}</div>
            <div className="meta">{j.company || 'Company'} · {j.location || 'Location'} · {j.job_type || 'Type'} · {j.is_open ? 'Open' : 'Closed'}</div>
            <p className="clamp">{j.description}</p>
          </Link>
        ))}
        {!loading && jobs.length === 0 && <div>No open jobs right now.</div>}
      </div>
    </div>
  )
}

