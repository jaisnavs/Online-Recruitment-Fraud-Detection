import React, { useEffect, useState } from 'react'
import api from '../api/client'

export default function Applications() {
  const [apps, setApps] = useState([])
  const [status, setStatus] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = async () => {
    setLoading(true)
    setError('')
    try {
      const res = await api.get('/applications', { params: { status: status || undefined } })
      setApps(res.data)
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to load applications')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [status])

  return (
    <div>
      <h2>My Applications</h2>
      <div className="card">
        <label>Status Filter</label>
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All</option>
          <option value="applied">Applied</option>
          <option value="accepted">Accepted</option>
          <option value="rejected">Rejected</option>
        </select>
      </div>
      {loading && <div>Loading...</div>}
      {error && <div className="error">{error}</div>}
      <div className="list">
        {apps.map((a) => (
          <div key={a.id} className="list-item">
            <div className="title">Application #{a.id}</div>
            <div className="meta">Job ID #{a.job_id} · {new Date(a.created_at).toLocaleString()}</div>
            <div className={`badge ${a.status}`}>{a.status}</div>
            {a.note && <div className="meta">Note: {a.note}</div>}
          </div>
        ))}
        {!loading && apps.length === 0 && <div>No applications yet.</div>}
      </div>
    </div>
  )
}
