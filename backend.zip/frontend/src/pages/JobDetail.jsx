import React, { useEffect, useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import api from '../api/client'
import { useAuth } from '../state/AuthContext'

export default function JobDetail() {
  const { id } = useParams()
  const nav = useNavigate()
  const { user } = useAuth()
  const [job, setJob] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [applyError, setApplyError] = useState('')
  const [applying, setApplying] = useState(false)

  useEffect(() => {
    setLoading(true)
    api.get(`/jobs/${id}`)
      .then((res) => setJob(res.data))
      .catch((e) => setError(e.response?.data?.detail || 'Failed to load job'))
      .finally(() => setLoading(false))
  }, [id])

  if (loading) return <div>Loading...</div>
  if (error) return <div className="error">{error}</div>
  if (!job) return <div>Not found</div>

  return (
    <div>
      <h2>{job.title}</h2>
      <div className="meta">ID #{job.id} · {job.is_open ? 'Open' : 'Closed'} · Recruiter #{job.recruiter_id}</div>
      <p style={{ whiteSpace: 'pre-wrap' }}>{job.description}</p>
      <Link to="/predict" className="btn">Check Fraud Probability</Link>
      {user?.role === 'seeker' && job.is_open && (
        <div style={{ marginTop: 12 }}>
          <button
            className="btn"
            disabled={applying}
            onClick={async () => {
              setApplying(true)
              setApplyError('')
              try {
                await api.post(`/jobs/${job.id}/apply`)
                alert('Application submitted')
              } catch (e) {
                const msg = e.response?.data?.detail || 'Failed to apply'
                setApplyError(msg)
                if (e.response?.status === 400 && String(msg).toLowerCase().includes('complete your profile')) {
                  alert('Please complete your profile (name and resume) to apply.')
                  nav('/profile')
                }
              } finally {
                setApplying(false)
              }
            }}
          >{applying ? 'Applying...' : 'Apply'}</button>
          {applyError && <div className="error" style={{ marginTop: 8 }}>{applyError}</div>}
        </div>
      )}
    </div>
  )
}

