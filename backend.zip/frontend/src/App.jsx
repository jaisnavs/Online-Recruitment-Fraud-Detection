import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Navbar from './components/Navbar'
import Login from './pages/Login'
import Register from './pages/Register'
import SeekerDashboard from './pages/SeekerDashboard'
import RecruiterDashboard from './pages/RecruiterDashboard'
import JobDetail from './pages/JobDetail'
import Predict from './pages/Predict'
import { useAuth } from './state/AuthContext'
import Profile from './pages/Profile'
import Applications from './pages/Applications'

function PrivateRoute({ children, roles }) {
  const { user } = useAuth()
  if (!user) return <Navigate to="/login" replace />
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />
  return children
}

export default function App() {
  return (
    <div className="app">
      <Navbar />
      <div className="container">
        <Routes>
          <Route path="/" element={<SeekerDashboard />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/jobs/:id" element={<JobDetail />} />
          <Route path="/predict" element={<Predict />} />
          <Route
            path="/profile"
            element={
              <PrivateRoute roles={["seeker"]}>
                <Profile />
              </PrivateRoute>
            }
          />
          <Route
            path="/applications"
            element={
              <PrivateRoute roles={["seeker"]}>
                <Applications />
              </PrivateRoute>
            }
          />
          <Route
            path="/recruiter"
            element={
              <PrivateRoute roles={["recruiter"]}>
                <RecruiterDashboard />
              </PrivateRoute>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </div>
  )
}

