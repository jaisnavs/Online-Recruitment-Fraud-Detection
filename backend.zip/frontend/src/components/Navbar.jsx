import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../state/AuthContext'

export default function Navbar() {
  const { user, logout } = useAuth()
  const location = useLocation()

  return (
    <nav className="navbar">
      <div className="nav-left">
        <Link to="/" className="brand">Job Testing Portal</Link>
        <Link to="/" className={location.pathname === '/' ? 'active' : ''}>Jobs</Link>
        <Link to="/predict" className={location.pathname === '/predict' ? 'active' : ''}>Fraud Check</Link>
        {user?.role === 'seeker' && (
          <>
            <Link to="/profile" className={location.pathname === '/profile' ? 'active' : ''}>Profile</Link>
            <Link to="/applications" className={location.pathname === '/applications' ? 'active' : ''}>Applications</Link>
          </>
        )}
        {user?.role === 'recruiter' && (
          <Link to="/recruiter" className={location.pathname.startsWith('/recruiter') ? 'active' : ''}>Recruiter</Link>
        )}
      </div>
      <div className="nav-right">
        {user ? (
          <>
            <span className="user-tag">{user.email} · {user.role}</span>
            <button onClick={logout} className="btn">Logout</button>
          </>
        ) : (
          <>
            <Link to="/login" className="btn">Login</Link>
            <Link to="/register" className="btn btn-secondary">Register</Link>
          </>
        )}
      </div>
    </nav>
  )
}

