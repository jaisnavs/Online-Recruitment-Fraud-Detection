import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000',
})

let bearer = null

api.setToken = (token) => {
  bearer = token
}

api.interceptors.request.use((config) => {
  if (bearer) config.headers.Authorization = `Bearer ${bearer}`
  return config
})

export default api
