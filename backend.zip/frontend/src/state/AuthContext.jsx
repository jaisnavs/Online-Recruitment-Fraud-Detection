import React, { createContext, useContext, useEffect, useState } from 'react'
import api from '../api/client'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [token, setToken] = useState(localStorage.getItem('token') || null)

  useEffect(() => {
    if (token) {
      localStorage.setItem('token', token)
      api.setToken(token)
      api.get('/auth/me')
        .then((res) => setUser(res.data))
        .catch(() => {
          setUser(null)
          setToken(null)
          localStorage.removeItem('token')
          api.setToken(null)
        })
    } else {
      localStorage.removeItem('token')
      api.setToken(null)
      setUser(null)
    }
  }, [token])

  const login = async (email, password) => {
    const data = new URLSearchParams()
    data.append('username', email)
    data.append('password', password)
    const res = await api.post('/auth/login', data, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    })
    setToken(res.data.access_token)
  }

  const logout = () => {
    setToken(null)
  }

  const register = async (email, password, role) => {
    await api.post('/auth/register', { email, password, role })
  }

  return (
    <AuthContext.Provider value={{ user, token, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
